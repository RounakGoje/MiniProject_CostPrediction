<?php 

//searchdbcon.php

$connect = new PDO("mysql:host=localhost;dbname=project", "root", "");

?>