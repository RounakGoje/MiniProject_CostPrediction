<!DOCTYPE HTML>

<html>
	<head>
		<title>Service Verification</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<link rel="stylesheet" href="assets2/css/main.css" />
		
	</head>
	<body>

        <section style="background: rgb(245,233,174);
background: linear-gradient(180deg, rgba(245,233,174,0.7122199221485469) 0%, rgba(189,158,5,0.6113795860140931) 100%);" >
       <section id="a" >
		<!-- Banner -->
			<section id="banner" style="color: black" >
                <br>
				<h2><strong>Thankyou</strong>  for verifying Service!!!</h2>
				<p>Please Reach To Client as soon as possible!!! </p>
				<ul class="actions">
					<li><a href="http://localhost/p/miniproject/clientlogin.php" class="button special">Client Login</a>&nbsp;
						<a href="http://localhost/p/miniproject/servicelogin.php" class="button special">Service Login</a>&nbsp;
                        <a href="http://localhost/p/miniproject/landding%20page/index.php" class="button special">Home Page</a>   </li>
                    
				</ul>
                
			</section>
</section>
	</section>
		
		
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
		
			<script src="assets/js/main.js"></script>

	</body>
</html>